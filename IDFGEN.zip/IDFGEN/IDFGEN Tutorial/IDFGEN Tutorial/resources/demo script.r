##########################################################
#
#  This file contains R code to be used with the IDFGEN tutorial
#
#  Most comments have been removed
#
#  Folders may have to be modified for your system.
#
#



#------------------------------------------------------------------------#
#                        Setting up R                                    #
#------------------------------------------------------------------------#
#  



  rm(list=ls())
  setwd("C:/R/MyProject")      # for example
  source("C:/R/IDFGEN/package/main.r", chdir = TRUE)     # for example
  


#------------------------------------------------------------------------#
#                        Importing Data                                  #
#------------------------------------------------------------------------#
#

  readInData("Input/sampledata.txt", 7)
  

#------------------------------------------------------------------------#
#                    Exploring the Data                                  #
#------------------------------------------------------------------------#

# For a Population
  OmyBBER11C
  summary(OmyBBER11C) 
  scores(OmyBBER11C)
  inds(OmyBBER11C)
  n(OmyBBER11C)
  m(OmyBBER11C) 
  metaData(OmyBBER11C)
  class(OmyBBER11C)

  OmyBBER11C$Scores
  OmyBBER11C$Individuals


#For a PopList
  Populations
  summary(Populations)
  inds(Populations) 
  n(Populations) 
  sum(n(Populations))
  metaData(Populations)
  class(Populations) 


# Markers
  Markers
  MarkersSNP
  MarkersUSAT
  

# Metadata
  MetaDataFields


#------------------------------------------------------------------------#
#                    Manipulating Objects                                #
#------------------------------------------------------------------------#

  
# PopLists
  myPops1 <- Populations[1:2]
  myPops1b <- Populations[c(1,2)]
  myPops1c <- c(OmyBBER11C, OmyBBER11C_1)
  myPops1
  myPops1b
  myPops1c


  myPops2 <- c("OmyBBER11C", "OmyBBER11C_1")
  class(myPops2) <- "PopList"
  myPops2
  myPops2b <- as.PopList("OmyBBER11C", "OmyBBER11C_1")
  myPops2b
     

# Markers
  myMarkers1 <- Markers[1:4]
  myMarkers2 <- MarkersSNP[c(1, 4, 5, 8)]
  myMarkers3 <- c("One103", "One104", "One108")


# Pooling Pops
  poolPops(myPops1, "OmyBBER11C_POOLED")

# Subpopulations

    myInds <- inds(OmyEFBB11C)
    indsForNewPop <- myInds[1:20]
    subPopulation(OmyEFBB11C, indsForNewPop, "OmyEFBB11C_subpop")


#------------------------------------------------------------------------#
#                    Cleaning Data                                       #
#------------------------------------------------------------------------#

failedInds <- findNoCalls(Populations, 15)
failedInds
dumpTable(failedInds, "Output/failedInds.txt")
removeIndividuals(failedInds)

failedIndsUSAT <- findNoCalls(Populations, 5, MarkersUSAT)
failedIndsUSAT

hybrids <- findAlleles(Populations, "M09AAJ163", "A")
hybrids
hybrids2 <- findAlleles(Populations, Markers[1:2], c("T", "A"))
hybrids2b <- findAlleles(Populations, c("M09AAD076", "M09AAJ163"), c("T", "A"))
hybrids2


duplicateInds <- findDuplicateInds(Populations, markers=Markers[1:10],2)
duplicateInds

duplicateInds2 <- findDuplicateInds(Populations, 2)
duplicateInds2


#------------------------------------------------------------------------#
#                    Exporting Data                                      #
#------------------------------------------------------------------------#



dumpBaseline(Populations, markers = MarkersSNP, fileType = "BAYES", filename = "Output/myBayesBaseline.txt")
dumpBaseline(Populations, markers = MarkersSNP, fileType = "SPAM", filename = "Output/mySPAMBaseline.bse")
dumpBaseline(Populations, markers = Markers, fileType = "gsi_sim", filename = "Output/myGSI_SIMBaseline.txt")

dumpMixture(OmyBBER11C, markers = Markers, fileType = "gsi_sim", filename = "Output/myGSI_SIMMixture.txt")
dumpMixture(OmyBBER11C, markers = MarkersSNP, fileType = "BAYES", filename = "Output/BayesMixture.txt")
dumpMixture(OmyBBER11C, markers = MarkersSNP, fileType = "SPAM", filename = "Output/SpamMixture.txt")

dumpColony(OmyBBER11C, markers = Markers, filename = "Output/myColonyFile.txt", errorDefaultValues = c(0,.005))

dumpGenepop(Populations, title = "My Title", filename = "Output/myGenepopFile.txt")
dumpGenepop(Populations[1:2], markers = MarkersSNP, title = "My Title", filename = "Output/myGenepopFile2.gen")
dumpGenepop(Populations, title = "My Title", filename = "Output/myGenepopFile3.txt", replaceBP = TRUE, basePairs = c("A", "C", "G", "T", "-"), replacements = c("1", "2", "3", "4", "5")) 

dumpGenAlEx(Populations, title = "My Title", filename = "Output/myGenAlExFile.txt")
dumpGenAlEx(Populations[1], markers = MarkersSNP, title = "My Title", filename = "Output/myGenAlExFile2.gen")
dumpGenAlEx(Populations, title = "My Title", filename = "Output/myGenAlExFile3.txt", replaceBP = TRUE, basePairs = c("A", "C", "G", "T", "-"), replacements = c("1", "2", "3", "4", "5")) 

dumpMSToolKit(Populations, markers = Markers, filename = "Output/myMSToolKitFile.txt")

dumpPhylip(Populations, markers = Markers, filename = "Output/myPhylipFile.txt")

dumpSNPPIT(baselinePops = Populations[1:3], mixturePops = Populations[4], markers = MarkersSNP, filename = "Output/mySNPPITFile.txt", errorFile = "Input/Allele Error Rates.txt", errorDefaultValue = .005)

dumpStructure(Populations, markers = Markers, filename = "Output/myStructureFile.txt")

  
 






















