########## R-Scripts For CRITFC Demo 01-19-2012 ##########################
#
#    created by MA on 1/19/12
#    edited for v2 by EG on 2/21/12
#
#    Progeny Export Format:
#     -wide (one row per individual)
#     -Pedigree and Individual name (unique ID)
#     -two columns per call
#     -A,C,G,T
#     -don't recode uSats
#     -no calls = 0
#     -include column headings
#
##########################################################################

##########################################################################
##########################################################################
############## IMPORT CRITFC FORMAT DATA - SNP DATA SET ##################
##########################################################################
##########################################################################

#------------------------------------------------------------------------#
#                       SETTING UP THE R-ENVIRONMENT                     #
#------------------------------------------------------------------------#

  rm(list=ls())  # Removes current objects that may be in R-workspace (RESET BUTTON). Use every time you start a new analysis.

  setwd("C:/R/MyProject")      # for example
 
  source("C:/R/IDFGEN/package/main.r", chdir = TRUE)  
  
 

#------------------------------------------------------------------------#
#                               IMPORT DATA                              #
#------------------------------------------------------------------------#

  ls()
  #inputFile and genotypeStartColumn are REQUIRED arguments
  #popColumn is OPTIONAL argument. By default readInData parses populations according to column 1 (PEDIGREE for IDFG)...can change to parse by another column.

  #   The following function would combine the columns  "Location" and "Date - Year Only"  to create populations
  #readInData("Input/CRITFC_Steelhead dataset for Rscripting.txt",
  #            genotypeStartColumn = 20,
  #            popColumn = c(13,7))


  # Creates populations using the "Location" column - number 13
  readInData("Input/CRITFC_Steelhead dataset for Rscripting.txt",
              genotypeStartColumn = 20,
              popColumn = 13)


#------------------------------------------------------------------------#
#                        EXPLORING THE DATA                              #
#------------------------------------------------------------------------#

 Columbia.River.Clackamas
 scores(Columbia.River.Clackamas)                     #the genotypes
 metaData(Columbia.River.Clackamas)                  #the individual data
 head(metaData(Columbia.River.Clackamas))

 Populations
 n(Populations)
 
 
#------------------------------------------------------------------------#
#                       MAKING POP AND MARKER LISTS                      #
#------------------------------------------------------------------------#

  snp.panel  <- Markers[-match(c("Ocl_gshpx357", "Omy_Omyclmk43896", "Omy_myclarp404111", "OmyY1_2SEXY"), Markers)]  #Subtract SNPs
  snp.panel2 <- snp.panel[-(c(188, 187))]
  some.pops  <- as.PopList("Mill.Cr.", "North.Fork.Dam.Clackamas.River", "North.Fork.John.Day.Camus.Creek", "North.Fork.John.Day.Columbia.RiverBig.Wall.Creek",
                  "North.Fork.John.Day.Desolation.Creek", "North.Fork.John.Day.Fox.Creek", "North.Fork.Lewis...Merwin.Dam",
                  "Oregon..Rock.Creek", "Oregon.Coast.L..Rock.Creek", "Oregon.Coast.Mad.Creek")
  some.pops2 <- some.pops[-match(c("Mill.Cr.", "Oregon..Rock.Creek"),some.pops)]
  more.pops <- as.PopList(some.pops, "South.Fork.John.Day.Murderer.s.Creek")

#------------------------------------------------------------------------#
#                  LOOK AT ALL THE FILES WE CAN MAKE                     #
#------------------------------------------------------------------------#

#
  dumpGenepop(some.pops, markers = snp.panel, title = "some.pops genepop", filename = "Output/critfc_genepop.txt")
  dumpGenepop(some.pops, markers = snp.panel, title = "some.pops.genepop", filename = "Output/critfc_genepop2.txt")


# dumpGenAlEx has exact same arguments as dumpGenepop!!!
  dumpGenAlEx(more.pops, markers = snp.panel, title = "some.pops genepop", filename = "Output/critfc_genalex.txt")

#
  dumpStructure(some.pops2, markers = snp.panel, "Output/critfc_structure.txt")
  dumpStructure(more.pops, markers = snp.panel, "Output/critfc_structure2.txt")

#
  dumpPhylip(some.pops, markers = snp.panel, filename = "Output/critfc_phylip.txt")

#
  dumpMSToolKit(some.pops, markers = snp.panel, filename = "Output/critfc_msToolKit.txt")

#
  dumpColony(Wenaha, markers = snp.panel, filename = "Output/critfc_colony.txt", errorDefaultValues = c(0,.005))
  poolPops(as.PopList("Wenaha", "Wiley.S.F..Santiam"), "colony.pop")
  dumpColony("colony.pop", markers = snp.panel, filename = "Output/critfc_colony.txt", errorDefaultValues = c(0,.005))

#
  dumpSNPPIT(baselinePops = some.pops, mixturePops = as.PopList("Wenaha"), markers = snp.panel, filename = "Output/critfc_snppit.txt", errorDefaultValue = 0.001)
  # Note: the function requires 2 PopLists, hence as.PopList("Wenaha")
  

#------------------------------------------------------------------------#
#                     EXPORTING INDIVIDUAL DATA                          #
#------------------------------------------------------------------------#

indData   <- metaData(some.pops)
indData2 <- indData[,c("Gender.via.conversion", "Latitude", "Longitude")]

dumpTable(indData2, file = "Output/critfc_metadata.txt", row.names = TRUE)

# dumpTable is a custom function which calls the following:
write.table(indData2, file = "Output/critfc_metadata2.txt", sep = "\t", quote = FALSE, col.names=NA)
