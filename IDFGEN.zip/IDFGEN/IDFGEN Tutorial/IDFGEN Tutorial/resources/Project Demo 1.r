  
##########################################################################
##########################################################################
############## COMBO PBT/GSI ANALYSIS - SNP DATA SET #####################
##########################################################################
##########################################################################


#------------------------------------------------------------------------#
#                       SETTING UP THE R-ENVIRONMENT                     #
#------------------------------------------------------------------------#

  rm(list=ls())  # Removes current objects that may be in R-workspace (RESET BUTTON). Use every time you start a new analysis.
  
  setwd("C:/R/MyProject")      # for example
  source("C:/R/IDFGEN/package/main.r", chdir = TRUE)  
 

#------------------------------------------------------------------------#
#                               IMPORT DATA                              #
#------------------------------------------------------------------------#

  readInData("Input/sthd_base_1.0_pbt_base_OmyLGRA09-12S_mixtures.txt", genotypeStartColumn = 27)





##########################################################################
################### CREATE 2008-2009 PBT BASELINE ########################
##########################################################################

#------------------------------------------------------------------------#
#                   SETTING UP POPULATION LISTS                          #
#------------------------------------------------------------------------#

### 2008 ###
  poolPops(as.PopList("OmyDWOR08S_04", "OmyDWOR08S_05", "OmyDWOR08S_06",
                        "OmyDWOR08S_07", "OmyDWOR08S_08", "OmyDWOR08S_09",
                        "OmyDWOR08S_10", "OmyDWOR08S_11", "OmyDWOR08S_12",
                        "OmyDWOR08S_13"),
            newName = "DWOR08S")


  poolPops(as.PopList("OmyPAHH08S" ,    "OmyPAHH08S_01" , "OmyPAHH08S_02"  ,
                         "OmyPAHH08S_03" , "OmyPAHH08S_04" , "OmyPAHH08S_05"  ,
                         "OmyPAHH08S_06" , "OmyPAHH08S_07" , "OmyPAHH08S_08"  ,
                         "OmyPAHH08S_09" , "OmyPAHH08S_10" , "OmyPAHH08S_11"  ,
                         "OmyPAHH08S_12" , "OmyPAHH08S_13" , "OmyPAHH08S_14") ,
            newName = "PAHH08S")


  poolPops(as.PopList("OmySAWT08S_01" , "OmySAWT08S_02" , "OmySAWT08S_03" ,
                         "OmySAWT08S_04" , "OmySAWT08S_05" , "OmySAWT08S_06" ,
                         "OmySAWT08S_07" , "OmySAWT08S_08" , "OmySAWT08S_09" ,
                         "OmySAWT08S_10"),
            newName = "SAWT08S")



### 2009 ###
  poolPops(as.PopList("OmyLYON09S_1" , "OmyLYON09S_2" , "OmyLYON09S_3" ,
                         "OmyLYON09S_4" , "OmyLYON09S_5"),
            newName = "LYONS09S")
  
  poolPops(as.PopList("OmyPAHH09S_01" , "OmyPAHH09S_02" , "OmyPAHH09S_03"  ,
                         "OmyPAHH09S_04" , "OmyPAHH09S_05" , "OmyPAHH09S_06"  ,
                         "OmyPAHH09S_07" , "OmyPAHH09S_08" , "OmyPAHH09S_09"  ,
                         "OmyPAHH09S_10" , "OmyPAHH09S_11", "OmyPAHH09S_12")  ,
            newName = "PAHH09S")



### Groups the 2008 hatcheries into a PopList
   pbtParents2008 <- as.PopList("OmyCGRW08S", "DWOR08S", "PAHH08S", "SAWT08S",
                         "OmySQUW08S", "OmyEFSW08S", "OmyOXBO08S")

### Groups the 2009 hatcheries into a PopList
   pbtParents2009 <- as.PopList("OmyCGRW09S", "OmyDWOR09S", "PAHH09S", "OmySAWT09S",
                          "OmySQUW09S", "OmyEFSW09S", "OmyOXBO09S" , "LYONS09S",
                          "OmyTOUW09S", "OmyTUCW09S", "OmyWALL09S")

### Groups both 2008 and 2009 hatcheries into 1 "vector" of populations
   pbtParents0809 <- as.PopList("OmyCGRW08S", "DWOR08S", "PAHH08S", "SAWT08S",
                          "OmySQUW08S", "OmyEFSW08S", "OmyOXBO08S",
                          "OmyCGRW09S", "OmyDWOR09S", "PAHH09S", "OmySAWT09S" ,
                          "OmySQUW09S", "OmyEFSW09S", "OmyOXBO09S", "LYONS09S",
                          "OmyTOUW09S", "OmyTUCW09S", "OmyWALL09S")

#------------------------------------------------------------------------#
#                        SETTING UP MARKER LISTS                         #
#------------------------------------------------------------------------#

Markers

#marker list for PBT analysis (Omy_SEXY1 & Omy_Ogo4212 removed)
pbt.analysis <- c("M09AAD076","M09AAJ163","M09AAE082","OMS00002","OMS00006","OMS00024","OMS00039","OMS00053","OMS00057","OMS00058","OMS00062",
"OMS00064","OMS00068","OMS00070","OMS00071","OMS00072","OMS00074","OMS00077","OMS00078","OMS00079","OMS00111","OMS00089","OMS00090","OMS00101","OMS00105","OMS00106",
"OMS00154","OMS00112","OMS00118","OMS00120","OMS00121","OMS00132","OMS00175","OMS00179","OMS00180","Omy_101832195","Omy_101993189","Omy_102505102","Omy_104519624",
"Omy_105105448","Omy_105385406","Omy_105714265","Omy_10780634","Omy_108007193","Omy_109243222","Omy_109894185","Omy_110064419","Omy_11138351","Omy_113490159",
"Omy_114315438","Omy_114587480","Omy_129870756","Omy_116733349","Omy_128923433","Omy_130524160","Omy_97660230","Omy_99300202","Omy_aldB165","Omy_anp17",
"Omy_arp630","Omy_b1266","Omy_BACB4324","Omy_ada1071","Omy_redd1410","Omy_cd59206","Omy_colla1525","Omy_cox1221","Omy_crb106","Omy_g1282","Omy_gluR79",
"Omy_hsc71580","Omy_hsf2146","Omy_IL17185","Omy_Il1b_028","Omy_Il1b198","Omy_IL6320","Omy_metA161","Omy_NaKATPa350","Omy_txnip343","Omy_nkef241","Omy_ntl27",
"Omy_bcAKala380rd","Omy_Ots249227","Omy_oxct85","Omy_p53262","Omy_rapd167","Omy_rbm4b203","Omy_srp0937","Omy_stat3273","Omy_u0953469",
"Omy_u0954311","Omy_U11_2b154","Omy_vatf406","OMY1011SNP")

 
 
 gsi.analysis  <- Markers[-match(c("Ocl_gshpx357", "Ocl_calT7RT2", "Omy_Omyclmk43896", "Omy_myclarp404111", "Omy_SEXY1", "Omy_mapK3103"), Markers)]


  
#------------------------------------------------------------------------#
#                    CLEANING UP PBT PARENTS                             #
#------------------------------------------------------------------------#

    #Find Failed PBT Parents
    failed.pbt.parents <- findNoCalls(pbtParents0809, markers = pbt.analysis, minNoCall = 10) 
    dumpTable(failed.pbt.parents, filename = "Output/failed_0809_pbt_parents.txt")
    removeIndividuals(failed.pbt.parents)

    #Find Duplicate PBT Parents
    duplicate.pbt.parents <- findDuplicateInds(pbtParents0809, markers = pbt.analysis, mismatchAllowed = 5)
    dumpTable(duplicate.pbt.parents, filename = "Output/duplicate_0809_pbt_parents.txt")
    removeIndividuals(duplicate.pbt.parents)
   
#------------------------------------------------------------------------#
#                    PBT PARENTS SAMPLE SIZES                            #
#------------------------------------------------------------------------#

   
    n(pbtParents0809)
    dumpTable(n(pbtParents0809), filename = "Output/pbt_parents_0809_sample_sizes.txt", row.names = TRUE)


##########################################################################
############# CREATE SNAKE RIVER STEELHEAD BASELINE v1.0 #################                                                      
##########################################################################

#------------------------------------------------------------------------#
#                   SETTING UP POPULATION LISTS                          #
#------------------------------------------------------------------------#

# Pool temporal collections
poolPops(as.PopList("OmySAWW05S", "OmySAWW10S"), "OmySAWW0510S")
poolPops(as.PopList("OmyBBER07S", "OmyBBER08S"), "OmyBBER0708S")
poolPops(as.PopList("OmyLBER07S", "OmyLBER08S"), "OmyLBER0708S")

# Populations in Snake River STHD Baseline v1.0 (note there are pooled pops)
sthd_base_1.0 <- as.PopList("OmySAWW0510S", "OmyWFYF04C", "OmyMORG00C", "OmyPAHS06S", "OmyNFSR10C", "OmyBOUL00C", "OmyHAZD00C", "OmyRAPD03S",
                   "OmySLAT00C", "OmyWHTB01C", "OmyMARS00C", "OmyRPDM00C", "OmyPSTL00C", "OmyCAMS00C", "OmyLOON99C", "OmyBIGC00C", "OmyBIGC00C_1",
                   "OmyBARG00C", "OmyEFSF00C", "OmySECS00C", "OmySFSR00C", "OmySTRM00C", "OmyCFLR00C", "OmyCANY04C", "OmyBEAR00C", "OmyNMOC04C",
                   "OmyGEDN00C", "OmyOHRA00C", "OmyCROK07S", "OmyTENM00C", "OmyJHNC00C", "OmyCLER00C", "OmyEFPR08S", "OmyBBER0708S",
                   "OmyLBER0708S", "OmyMISS00C", "OmyBSHP01C", "OmyCAMP01C", "OmyMOOO00C", "OmyLGHT00C", "OmyCRKC01C", "OmyELKC00C",
                   "OmyLMIN00C", "OmyLSTN00C", "OmyMENA99C", "OmyWENA01C", "OmyASOT00C", "OmyTUCA09S", "OmyTOUC95C")

#------------------------------------------------------------------------#
#              CLEANING UP SNAKE RIVER STEELHEAD BASELINE v1.0           #
#------------------------------------------------------------------------#

   failed.sthd.base.inds <- findNoCalls(sthd_base_1.0, markers = gsi.analysis, minNoCall = 19)
   dumpTable(failed.sthd.base.inds, filename = "Output/sthd_base_1 failed 10% SNPs.txt")
   removeIndividuals(failed.sthd.base.inds)
  
   sthd.base.hybrids <- findHybrids(sthd_base_1.0, markers = c("Omy_Omyclmk43896", "Omy_myclarp404111"), minorAlleles = c("C", "G"))
   dumpTable(sthd.base.hybrids, filename = "Output/sthd_base_1_putative_hybrids.txt")
   sthd.base.hybrids.noSAWW0510S <- sthd.base.hybrids[-c(1,2),]
      #The first two individuals were adults from the Sawtooth weir...I removed those from the list of hybrids
   removeIndividuals(sthd.base.hybrids.noSAWW0510S)
   
#------------------------------------------------------------------------#
#             SNAKE RIVER STEELHEAD BASELINE v1.0 SAMPLE SIZES           #
#------------------------------------------------------------------------#

 sthd_base_1.0_indcounts <- n(sthd_base_1.0)
 dumpTable(sthd_base_1.0_indcounts, row.names = TRUE, filename = "Output/sthd_base_1_sample_sizes.txt")
 
 

##########################################################################
######### CREATE SY2011 STHD ADULTS AT LOWER GRANITE DAM MIXTURE #########
##########################################################################

#------------------------------------------------------------------------#
#   SUBSET VALID SAMPLES OUT OF MIXTURE USING "SUBPOPULATION" FUNCTION   #
#------------------------------------------------------------------------#

     # Querying a pedigree's individual data for export
     metaData(OmyLGRA11S) 
     head(metaData(OmyLGRA11S))
     
     # We want to query "ValidSample = Y" from metaData(population) 
     # then take the inds(population) such that the query is TRUE
     OmyLGRA11S.valid.inds <- inds(OmyLGRA11S)[metaData(OmyLGRA11S)[,"ValidSample"]=="Y"]
    
     # The row names of all of the lines that meet the above criteria...
     OmyLGRA11S.valid.inds

     # Now we want to create a new "subpopulation" containing the above individuals...
     subPopulation(OmyLGRA11S, inds = OmyLGRA11S.valid.inds, newName = "OmyLGRA11S.valid")
     OmyLGRA11S.valid
     n(OmyLGRA11S.valid) #[1] 2309
     head(metaData(OmyLGRA11S.valid))
     # or equivalently: head(OmyLGRA11S.valid$IndividualData)

#------------------------------------------------------------------------#
#             CLEANING SY2011 STHD ADULTS @ LGD FOR ANALYSIS             #
#------------------------------------------------------------------------#

    failed.sy2011.mix  <- findNoCalls(OmyLGRA11S.valid, markers = gsi.analysis, minNoCall = 19)
    dumpTable(failed.sy2011.mix,  filename = "Output/sy2011mix.valid_failed_individuals.txt")
    scores(OmyLGRA11S.valid)[failed.sy2011.mix[,2], gsi.analysis]
    removeIndividuals(failed.sy2011.mix)
          

##########################################################################
##################### WRITING FILES FOR ANALYSIS #########################
##########################################################################

head(scores(OmySAWW0510S)[,gsi.analysis])

dumpBaseline(sthd_base_1.0, markers = gsi.analysis, fileType = "gsi_sim", filename = "Output/sthd_base_1_gsi_sim.txt")
dumpMixture(OmyLGRA11S.valid, markers = gsi.analysis, fileType = "gsi_sim", filename = "Output/sy2011_valid_gsi_sim.txt")


dumpSNPPIT(baselinePops = pbtParents0809, mixturePops = as.PopList("OmyLGRA11S.valid"), markers = pbt.analysis, filename = "Output/snppit_input.txt",  errorDefaultValue  = 0.005)



##########################################################################
########################### SNPPIT ANALYSIS ##############################
##########################################################################

# Set working directory where you will perform the snppit analysis. I keep an "analysis" folder in with snppit
setwd("C:/Users/mackerman/Desktop/R/snppit/analysis/")

# Copy your baseline, mixture, and reporting group files into the above directory...
# Also place a file called "gsi_sim_seeds" in the directory to store the random seeds from gsi_sim
dir()

# PATH to snppit.exe  (../ goes back one folder)
snppit.path <- "../snppit.exe"

# PATH of analysis files
input <- "./snppit_input.txt"

# Here we can use a paste statement to change/input parameters in gsi_sim...
# Essentially this is just what you would type into the command line...
args <- paste("-f",input);

# The system2 function in R invokes the OS command specified by command (i.e. calls gsi_sim)
system2(command=snppit.path, args=args)

# Change working directory back
setwd("C:/Users/mackerman/Desktop/R/")

##########################################################################
########################## GSI_SIM ANALYSIS ##############################
##########################################################################

# Set workind directory where you will perform the gsi_sim analysis. I keep an "analysis" folder in with gsi_sim
setwd("C:/Users/mackerman/Desktop/R/gsi_sim_pc/analysis/")

# Copy your baseline, mixture, and reporting group files into the above directory...
# Also place a file called "gsi_sim_seeds" in the directory to store the random seeds from gsi_sim
dir()

# PATH to gsi_sim.exe  (../ goes back one folder)
gsi.sim.path <- "../gsi_sim.exe"

# PATH of analysis files
base.path <- "./sthd_base_1_gsi_sim.txt"
mix.path  <- "./sy2011_valid_gsi_sim.txt"
rep.units <- "./sthd_base_1_rep_units.txt"

# Here we can use a paste statement to change/input parameters in gsi_sim...
# Essentially this is just what you would type into the command line...
args <- paste("-b",base.path,
              "-t",mix.path,
              "-r",rep.units,
              "--mcmc-burnin 100 --mcmc-sweeps 500 --pi-trace-interval 1"  # these are low reps, just so it doesn't take forever in testing
              );

# The system2 function in R invokes the OS command specified by command (i.e. calls gsi_sim)
status <- system2(command=gsi.sim.path, args=args)

# This is some script from Eric A. to plot the posterior distribution of Pi for the first 12 reporting groups
if(status==0) {
  pi.trace <- read.table("./rep_unit_pi_trace.txt",header=T,skip=1);
  par(mfrow=c(3,4));
  for(i in 1:12) {
    hist(pi.trace[,i+1],
         breaks=20,
         main=names(pi.trace)[i+1]
         )
  }

}

# Change working directory back
setwd("C:/Users/mackerman/Desktop/R/")

##########################################################################
########################### END OF ANALYSIS ##############################
##########################################################################
