loadPackages <- function(){
############################################################################
#
#  This function loads the required packages
#
#       abind    :   allows the combination of multidimensional arrays 
#       plyr     :   Tools for splitting, applying and combining data
#
  
  library("abind")
  library("plyr")
}


