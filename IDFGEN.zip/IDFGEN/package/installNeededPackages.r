installNeededPackages <- function(){
###########################################################################
#
#   This function installs the required packages from R's repository
#
#           abind    :   allows the combination of multidimensional arrays 
#           plyr     :   Tools for splitting, applying and combining data
#   
#
#   Note to user: this only needs to be run once
#

  install.packages("abind", repos = "http://cran.r-project.org")  
  install.packages("plyr", repos = "http://cran.r-project.org")  

}
 