######
#
#   This script generates a list of all function names in IDFGEN
#   and seperates them by category.
#
#


methodsIDFGEN <- function() {
  
  all <- ls("IDFGEN")
  
  p <- as.character(methods(class="Population"))
  pnames <- sapply(strsplit(p, split="[.]"), "[[", 1)
  
  pl <- as.character(methods(class="PopList"))
  plnames <- sapply(strsplit(pl, split="[.]"), "[[", 1)
 
  dump <- all[grep("dump*", all)]
  
  read <- all[grep("read*", all)]
  
  other <- all[!(all %in% c(p, pl, dump, pnames, plnames, read))]
  
  
# return
  list(Population = pnames,
       PopList = plnames,
       Read = read,
       Dump = dump,
       Other = other)
       
}




