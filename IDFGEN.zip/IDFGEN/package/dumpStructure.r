dumpStructure <- function(x, markers, filename, useIndNames = TRUE, popNumber = TRUE, replaceBP = TRUE, basePairs = c("A", "C", "G", "T", "-", "0"), replacements = c("1", "2", "3", "4", "5", "-9")) {

# Setup
  if (is.null(markers)) markers <- Markers
# One vs Many Pops
  if(class(x) == "PopList") {
    pops <- lapply(x, get)
  } else {
    pops <- list(x)
  }

# BP Formatting
  if(replaceBP) pops <- lapply(pops, replaceBPs, basePairs, replacements)


# write markers
  write(markers, filename, ncol = length(markers))

# calculate pop column width and create column
  popNames <- unlist(lapply(pops, names))
  indNames <- unlist(lapply(pops, inds))
  indCounts <- unlist(lapply(pops, n))

  if (useIndNames) {
    col1Width <- max(nchar(indNames)) + 1
    column1 <- rep(indNames, rep(2, length(indNames)))
  } else {
    col1Width <- max(nchar(popNames)) + 1
    popColumn <- rep(popNames, indCounts * 2)
  }

  popIndex <- rep(1:length(popNames), indCounts * 2)

# Arrange Scores 2 lines per inds
  structFormat <- function(x, markers) {

    d <- array(dim = c(n(x) * 2, length(markers)))
    d[1:n(x) * 2 - 1, ] <- x$Scores[,markers,1]
    d[1:n(x) * 2, ] <- x$Scores[,markers,2]
    d
  }
  scores <- lapply(pops, structFormat, markers)
  scores <- do.call(rbind, scores)

# Formatting widths of output

  column1 <- format(column1, width = col1Width)
  popIndex <- format(as.character(popIndex), width = 5)
  scores <- format(scores, width = 5)

  if(popNumber) {
    output <- cbind(column1, popIndex, scores)
  } else {
    output <- cbind(column1, scores)
  }

  write.table(output, file=filename, a = TRUE, quote = FALSE, row.names = FALSE, col = FALSE, sep= "")

  cat("A Structure file has been written to", filename, "\n")

}

