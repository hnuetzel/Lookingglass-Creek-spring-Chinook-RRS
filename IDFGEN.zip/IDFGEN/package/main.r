###############
# main.r
#

  require("plyr", q=TRUE)
  require("abind", q=TRUE)
  
# create environment
  if ("IDFGEN" %in% search()) detach(IDFGEN)
  if ("IDFGEN_Data" %in% search()) detach(IDFGEN_Data)
 
  IDFGEN <- new.env()

# load fstats.r script
  if ((!"fstats" %in% search())) {
    fstats <- new.env()
    sys.source("fstats.r", fstats)
    attach(fstats)
    rm(fstats)
  }

# load all functions
  files <- list.files(pattern="*.[rR]$", recursive=TRUE,include.dirs=TRUE)
  files <- files[files!="main.r"]
  files <- files[files!="fstats.r"]
  sapply(as.list(files), sys.source, IDFGEN)
  rm(files) 
  
# attach and cleanup
  attach(IDFGEN)
  rm(IDFGEN, pos = 1)
  
# message
  cat("\n")
  cat("*** IDFG Genetic Functions Package v0.2.8 ***\n")
  cat("*** Last updated 05/25/2012\n\n")
  cat("*** see methodsIDFGEN() for available functions. ***\n\n")
  
 
  
  
  
  
  
  
  
  # # R setup
#   sys.source("installNeededPackages.r", IDFGEN)
#   sys.source("loadPackages.r", IDFGEN)
#   sys.source("generics.r", IDFGEN)
#      
# # classes
#   sys.source("Population.r", IDFGEN)
#   sys.source("PopList.r", IDFGEN)
# 
# # import functions
#   sys.source("readInData.r", IDFGEN)
#   sys.source("readBAPS.r", IDFGEN)
# 
# 
# # helper functions
#   sys.source("clearSession.r", IDFGEN)
#   sys.source("dumpTable.r", IDFGEN)  
#   sys.source("replaceBPs.r", IDFGEN)
#   sys.source("methodsIDFGEN.r", IDFGEN)
#   
#   
# # output functions
#   sys.source("dumpGenepop.r", IDFGEN)
#   sys.source("dumpGenAlEx.r", IDFGEN)
#   sys.source("dumpBaseline.r", IDFGEN)
#   sys.source("dumpMixture.r", IDFGEN)
#   sys.source("dumpMSToolKit.r", IDFGEN)
#   sys.source("dumpStructure.r", IDFGEN)
#   sys.source("dumpPhylip.r", IDFGEN)
#   sys.source("dumpSNPPIT.r", IDFGEN)
#   sys.source("dumpColony.r", IDFGEN)
  
  
  
