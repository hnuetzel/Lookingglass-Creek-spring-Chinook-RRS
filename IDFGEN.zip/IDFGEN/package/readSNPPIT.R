readSNPPIT <- function(filename, K=NULL, P=NULL, M=NULL) {
  
  # get snppit data
  snppit <- read.table(filename, sep ="\t", header=TRUE)
  
  # only use samples in a R Population
  snppit <- snppit[snppit[,"PopName"] %in% Populations,]
  
  # get metadata columns of crosses
  crossColumns <- grep("Crossed", MetaDataFields)
  
# Main crossmatch function
  crossMatch <- function(x, crossCol,K,M,P) {
    # setup - get pop data, meta data, and ind names
    pop <- get(x["PopName"])
    kidpop <- get(x["OffspCollection"])
    crosses <- metaData(pop)[,crossCol]
    Kid <- x["Kid"]
    Ma <- x["Ma"]
    Pa <- x["Pa"]
    
    # get matches and metadata
    PinM <- Pa %in% crosses[Ma,]
    MinP <- Ma %in% crosses[Pa,]
    match <- sum(c(PinM, MinP))
    if(match!=1) {
      maCrossedWith <- vector("character", length(crossCol))
      paCrossedWith <- vector("character", length(crossCol))
    }else {
      maCrossedWith <- crosses[Ma,]
      paCrossedWith <- crosses[Pa,]
    }
    
    # extra metadata fields  
    
    if(is.null(K)) KidData <- ""
    else KidData <- metaData(kidpop)[Kid, K]
    
    if(is.null(P)) PaData <- ""
    else PaData <- metaData(pop)[Pa, P]
    
    if(is.null(M)) MaData <- ""
    else MaData <- metaData(pop)[Ma, M]
    
    
    # return results  
    list(match=match, Pa=paCrossedWith, Ma=maCrossedWith, KidData=KidData, PaData=PaData, MaData=MaData)  
  } #end crossMatch function
  
  
  # find cross matches
  crosses <- apply(snppit, MARGIN=1, crossMatch, crossColumns, K=K, M=M, P=P)
  
  # matches
  matches <- laply(crosses, "[[", "match")
  crossOutput <- matches
  crossOutput[matches==0] <- "N/A"
  crossOutput[matches==1] <- "BUMMER"
  crossOutput[matches==2] <- "MATCH"
  CrossMatch <- crossOutput
  
  # format CrossedWith columns
  PaCols <- do.call(rbind, llply(crosses, "[[", "Pa"))
  MaCols <- do.call(rbind, llply(crosses, "[[", "Ma"))
  colnames(PaCols) <- paste("Pa_", MetaDataFields[crossColumns] ,sep="") 
  colnames(MaCols) <- paste("Ma_", MetaDataFields[crossColumns] ,sep="") 
  CrossCols <- cbind(PaCols, MaCols)
  
  # Format metaDataColumns
  KDataCols <- do.call(rbind, llply(crosses, "[[", "KidData"))
  colnames(KDataCols) <- paste("Kid_", K, sep = "")
  PaDataCols <- do.call(rbind, llply(crosses, "[[", "PaData"))
  colnames(PaDataCols) <- paste("Pa_", P, sep = "")
  MaDataCols <- do.call(rbind, llply(crosses, "[[", "MaData"))
  colnames(MaDataCols) <- paste("Ma_", M, sep = "")
  
  # Combine all results and filter out empty columns 
  results <- cbind(snppit[,1:2], KDataCols, snppit[,3, drop=FALSE], PaDataCols, snppit[,4,drop=FALSE], MaDataCols, CrossMatch, CrossCols, snppit[5:ncol(snppit)])
  results <- results[,unlist(lapply(alply(results, 2, table,exclude=""),length))>0]
  results
  
}

summarySNPPIT <- function(snppitResult) {
  snppitPops <- unique(snppitResult[,"PopName"])
  snppitSummary <- do.call(rbind, lapply(snppitPops, function(p) c(as.character(p),table(subset(snppitResult, PopName==p, select=CrossMatch)))))
  snppitSummary
}