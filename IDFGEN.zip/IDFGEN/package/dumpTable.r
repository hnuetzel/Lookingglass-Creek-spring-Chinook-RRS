dumpTable <- function(x, filename, row.names = FALSE, sep = "\t") {

  write.table(x, file = filename, append = FALSE, quote = FALSE, sep = sep,
            row.names = row.names, col.names = if(row.names) NA else TRUE)


}