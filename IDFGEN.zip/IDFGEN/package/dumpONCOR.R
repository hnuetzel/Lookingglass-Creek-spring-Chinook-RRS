dumpONCOR <- function(x, 
                        markers = NULL,   
                        title,
                        filename,
                        popNames = FALSE,
                        replaceBP = TRUE, 
                        basePairs = c("A", "C", "G", "T", "-", "0"), 
                        replacements = c("102", "104", "106", "108", "100", "000")) {
  
  
# Markers
  if (is.null(markers)) markers <- Markers
  snps <- markers[markers %in% MarkersSNP]
  usats <- markers[markers %in% MarkersUSAT]
  
  
# One vs Many Pops  
  if(class(x) == "PopList") {
    pops <- lapply(x, get)
  } else {
    pops <- list(x)
  }
  
# Formating
  if(replaceBP) pops <- lapply(pops, replaceBPs, basePairs, replacements)
  
  formatScores <- function(x, snps, usats, popNames) {
    
    x$Scores[,snps,][x$Scores[,snps,]==0] <- "000"
    x$Scores[,usats,][x$Scores[,usats,]==0] <- "000"
    gen <- oneColScores(x)
    if (popNames==FALSE) {
      out <- cbind(paste(inds(x), ",", sep = ""), gen[,markers])
    } else {
      out <- cbind(paste(names(x), ",", sep = ""), gen[,markers])
    }
    out
  }
  
  genepopScores <- lapply(pops, formatScores, snps, usats, popNames)
  
  
# Output
  write(c(title, markers), file = filename, ncolumns = 1, sep = "")
  
  writePop <- function(x) {
    write("pop", file = filename, ncolumns = 1, sep = "", append = TRUE)
    write.table(x, file = filename, quote = FALSE, sep = " ", row.names = FALSE, col.names = FALSE, append = TRUE)
  }
  
  lapply(genepopScores, writePop)
  cat("***", filename, "has been written. ***\n")
  
  
}