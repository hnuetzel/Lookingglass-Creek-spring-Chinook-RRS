

readBAPS <- function(filename, popName, newPopNamePrefix, popListNewName) {
##############################################################333
#
#    Reads in BAPS output and creates new populations based on clusters
#
#         filename          :   BAPS output filename and path
#         popName           :   name of population in BAPS output
#         newPopNamePrefix  :   prefix for all new pops created by this function
#         popListNewName    :   name for PopList outputted
#
#   Example
# readBaps("C:/myBAPSFile.txt", "myPopulation", "myBAPSCluster", "BAPSPopNames")
#
#
#
# get pop data
  if (class(popName)=='Population') {
    pop <- popName
  } else if (class(popName)=='character') {
    pop <- get(popName)
  } else { 
    return(cat("Argument for 'popName' is not a Population or\nthe name of a Populaton.\n"))
  }

# read in Data to vector for later parsing
  rawBAPS <<- scan(filename, what = '', sep = " ", strip.white = TRUE, quiet = TRUE)
  
# remove blanks, commas, curly brackets
  rawBAPS <- rawBAPS[rawBAPS != ""]
  rawBAPS <- gsub("[{]", "", rawBAPS)
  rawBAPS <- gsub("[}]", "", rawBAPS)
  rawBAPS <- gsub(",", "", rawBAPS)

# PARSER   (uses specific features in BAPS output)
  numberOfClusters <- as.integer(rawBAPS[grep("partition:", rawBAPS)[1] + 1])  # number of pops follows first "partion:" string
  clusterStarts <- grep("Cluster", rawBAPS, fixed = TRUE)[1:numberOfClusters]  # gets indicies of "Cluster"
  lastClusterEnd <- grep("Changes", rawBAPS) # last data point is right before "Changes"
  clusterIndex <- c(clusterStarts, lastClusterEnd)
  clusters <- vector(length= numberOfClusters)
  
# Create new pops    
  for (i in 1:numberOfClusters) {
    inds <- as.integer(rawBAPS[(clusterIndex[i] + 2):(clusterIndex[i+1] - 1)]) # inds start 2 indices after "Cluster" and end right before next "Cluster"
    inds <- inds(pop)[inds]
    subPopulation(pop, inds, paste(newPopNamePrefix, i, sep = ""))
  }
  
# Create PopList
  assign(popListNewName, as.PopList(paste(newPopNamePrefix, 1:numberOfClusters, sep = "")), pos = 1)
  
  cat("\n***\n***A new PopList, '", popListNewName, "' has been created with all clusters.\n")
    
}
  

# 
# 
# 
# # create new pops using parse data
#   for (i in 1:numberOfClusters) {
# 
#     
#     tempScores <- popData$Scores[inds,,]
#     tempIndData <- popData$IndividualData[inds,]
#     
#     tempPopData <- list(Scores = tempScores, IndividualData = tempIndData, Info = list(popName = paste(bapsPopID,i, sep =""), inputDate = Sys.Date()))
#     clusters[i] <- paste(bapsPopID, i, sep = "")
#   
#   # save population
#     assign(paste(bapsPopID, i, ".data", sep = ""), tempPopData, pos = 1)
#   } # end cluster loop
# # 
# # # output new pop names vector
# #   assign(bapsRname, clusters, pos = 1)
# # 
# # # output to console
# #   print(paste(numberOfClusters, "new populations created"))
# #   print(clusters, ncol = numberOfClusters)
# #   
# # }
