dumpMSToolKit <- function(x, markers = NULL, filename, replaceBP = TRUE, basePairs = c("A", "C", "G", "T", "-"), replacements = c("1", "2", "3", "4", "5"))
{

# Setup
  if (is.null(markers)) markers <- Markers
# One vs Many Pops
  if(class(x) == "PopList") {
    pops <- lapply(x, get)
  } else {
    pops <- list(x)
  }

# BP Formatting
  if(replaceBP) pops <- lapply(pops, replaceBPs, basePairs, replacements)


# Output  
  write(paste("", markers, sep = "\t"), filename, ncol = length(markers) * 2, sep = "\t")

  scores <- lapply(pops, twoColScoresAlt, markers)
  output <- do.call(rbind, scores)

  write.table(output, file = filename, append = TRUE, quote = FALSE, sep = "\t ",
            row.names = TRUE, col.names = FALSE)

  cat("A MSToolKit file has been written to", filename, "\n")

}
